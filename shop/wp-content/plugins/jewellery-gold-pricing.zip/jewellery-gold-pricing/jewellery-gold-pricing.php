<?php
/*
Plugin Name: Jewellery Gold Pricing by RK
Description: Dynamic gold price calculator for WooCommerce jewellery products.
Version: 1.0
Author: Rajanikanta Biswal
*/

if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'includes/admin-settings.php';
require_once plugin_dir_path(__FILE__) . 'includes/product-fields.php';
require_once plugin_dir_path(__FILE__) . 'includes/price-calculation.php';
require_once plugin_dir_path(__FILE__) . 'includes/price-breakup-popup.php';
